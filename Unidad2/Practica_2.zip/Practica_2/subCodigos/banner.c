#include <stdlib.h>
#include <stdio.h>

int banner() {
    printf("=======================================================================================================\n\n");
    printf(" 88888888ba                                                88                              ad888888b,        \n");
    printf(" 88      \"8b                                        ,d     \"\"                             d8\"     \"88        \n");
    printf(" 88      ,8P                                        88                                            a8P        \n");
    printf(" 88aaaaaa8P'  8b,dPPYba,  ,adPPYYba,   ,adPPYba,  MM88MMM  88   ,adPPYba,  ,adPPYYba,          ,d8P\"         \n");
    printf(" 88\"\"\"\"\"\"\"'   88P'   \"Y8  \"\"     `Y8  a8\"     \"\"    88     88  a8\"     \"\"  \"\"     `Y8        a8P\"            \n");
    printf(" 88           88          ,adPPPPP88  8b            88     88  8b          ,adPPPPP88      a8P'              \n");
    printf(" 88           88          88,    ,88  \"8a,   ,aa    88,    88  \"8a,   ,aa  88,    ,88     d8\"                \n");
    printf(" 88           88          `\"8bbdP\"Y8   `\"Ybbd8\"'    \"Y888  88   `\"Ybbd8\"'  `\"8bbdP\"Y8     88888888888        \n\n\n");
    printf("=======================================================================================================\n\n");
    printf("    Elaboraron:                             ||    Grupo:\n");
    printf("        - Ayala Fuentes Sunem Gizeht        ||        4CM1\n");
    printf("        - Campos Zeron Salvador             ||\n\n");
    printf("=======================================================================================================\n\n");
}