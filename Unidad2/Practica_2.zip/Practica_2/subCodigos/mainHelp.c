#include "help.c"

int main(){
    help();
}