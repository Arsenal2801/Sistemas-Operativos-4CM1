#include <stdlib.h>
#include <stdio.h>

int help(){
      printf("**Comandos disponibles:**\n");
  printf("\n");
  printf("1. printPpid - Imprime la información del ID proceso padre\n");
  printf("2. printPid - Imprime la información del ID del proceso\n");
  printf("3. printGroup - Imprime la información del grupo del proceso\n");
  printf("4. printSesion - Imprime la información de la sesión\n");
  printf("5. printUser - Imprime la información del usuario que ejecutó el proceso\n");
  printf("6. PrintSerieFibonacci (n) - Imprime el elemento n de la serie fibonacci\n");
  printf("7. help - Imprime esta lista\n");
  printf("\n");
}