#!/bin/bash

echo "_____________________________________________________________"
echo "_____________________________________________________________"
echo "                          Practica 1                         "
echo "Elaboró:"
echo "       - Ayala Fuentes Sunem Gizeht"
echo "       - Campos Zeron Salvador"
echo "_____________________________________________________________"
echo "_____________________________________________________________"

echo "Opciones:"
echo "        1.- Imprime las lineas de syslog"
echo "        2.- Valida la informacion de 3 archivos"
echo "        3.- "
