#!/bin/bash

# Imprimir las ultimas 15 lineas del log del sistema (/var/log/syslog) en orden inverso
# redirigir la salida estandar a un archivo de texto que se llame syslog.txt
# redirigir los errores al archivo /dev/null

ROUTE="/var/log/syslog"
LAST_LINES=$(tail -n 15 $ROUTE)2>/dev/null
INVERT_LINES=$(echo "$LAST_LINES" | tac)
echo "$INVERT_LINES" >> syslog.txt

if [ $? -ne 0 ]; then
  echo "Error al escribir en el archivo syslog.txt" >&2
fi
